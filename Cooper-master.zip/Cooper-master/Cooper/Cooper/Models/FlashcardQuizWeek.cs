﻿using System;
namespace Cooper.Models
{
    //Done by Ryuta
    public class FlashcardQuizWeek
    {
        public string Title { get; set; }
    }
}
