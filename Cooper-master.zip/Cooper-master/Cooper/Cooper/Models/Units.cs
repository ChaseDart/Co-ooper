﻿using System;
namespace Cooper.Models
{
    //Done by Ryuta
    public class Units
    {
        public string UnitName { get; set; }

        public static implicit operator Units(string v)
        {
            throw new NotImplementedException();
        }
    }
}
