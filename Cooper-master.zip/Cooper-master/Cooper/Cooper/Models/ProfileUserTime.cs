﻿using System;
using ChartEntry = Microcharts.ChartEntry;
using System.Collections.Generic;
using System.Text;
using System.Runtime.CompilerServices;
using Microcharts;

namespace Cooper.Models
{
    //Done by Chase
    public class UserLogData
    {
        public DateTime DatesLogged { get; }
        public int TimeSpent { get; }

        public UserLogData(DateTime datesLogged, int timeSpent)
        {
            DatesLogged = datesLogged;
            TimeSpent = timeSpent;
        }
    }
    
    public struct userProfile
    {
        public string userName;
        public string userStudentNumber;
        public string userBio;
        public string Stars;
        public string Money;
        public List<UserLogData> data;
        public List<UserLogData> UserLogData;
        public List<ChartEntry> userWeekChartEntry;
        //public List<ChartEntry> userMonthChartEntry;
        //public List<ChartEntry> userYearChartEntry;
        public List<UserClasses> ClassMockData;
    }
}
