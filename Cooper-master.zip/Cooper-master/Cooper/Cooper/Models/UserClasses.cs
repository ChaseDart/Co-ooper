﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cooper.Models
{
    //Done by Chase
    public class UserClasses
    {
        public string ClassName { get; set; }
        public int ClassTotal { get; set; }
        public int UserTotal { get; set; }
    }
}

