﻿using System;
using SQLite;

namespace Cooper.Models
{
    //Done by Ryuta
    public class WeekQuizStatus
    {
        [PrimaryKey]
        public int Week { get; set; }
        public string IsCompleted { get; set; }
    }
}
