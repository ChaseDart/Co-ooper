﻿using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Jason
    class MainPageViewModel : BaseViewModel
    {
        public List<Units> UnitName { get; set; }
        public Command LogoutCommand { get; }
        public Command<string> UnitCommand { get; } 
        public Command UnitAddCommand { get; }
        public Command ProfileCommand { get; }
        public Command SettingCommand { get; }
        public MainPageViewModel()
        {
            UnitName = new MockUnitDataStore().GetUnitsNameList();
            LogoutCommand = new Command(LogoutButtonClicked);
            UnitCommand = new Command<string>(UnitButtonClicked);
            UnitAddCommand = new Command(AddUnitButtonClicked);
            SettingCommand = new Command(SettingButtonClicked);
            ProfileCommand = new Command(ProfilePageClicked);
        }
        

        private async void LogoutButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(LoginPage)}");
        }

        private async void ProfilePageClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(ProfilePage)}");
        }

        private async void UnitButtonClicked(string i)
        {
            if(UnitName[int.Parse(i)].UnitName == "IAB330")
            {
                await Shell.Current.GoToAsync($"//{nameof(UnitMenuPage)}");
            }
            else
            {
                await Application.Current.MainPage.DisplayAlert(UnitName[int.Parse(i)].UnitName, "This unit is currently not available", "Ok");
            }
            
        }

        private async void AddUnitButtonClicked(object obj)
        {
            UnitAddModalPage unitAddModalPage = new UnitAddModalPage();
            await Application.Current.MainPage.Navigation.PushModalAsync(unitAddModalPage, animated: false);
        }
        private async void SettingButtonClicked(object obj)
        {
            await Application.Current.MainPage.DisplayAlert("Setting Feature", "This feature is currently not available", "Ok");
        }
    }
}
