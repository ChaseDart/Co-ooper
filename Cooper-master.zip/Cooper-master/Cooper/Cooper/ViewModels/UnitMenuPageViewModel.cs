﻿using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.TizenSpecific;

namespace Cooper.ViewModels
{
    //Done by Jason
    class UnitMenuPageViewModel : BaseViewModel
    {
        public Command BackCommand { get; }
        public Command QuizCommand { get; }
        public Command FlashcardCommand { get; }
        public Command ChatCommand { get; }
        public Command LeaderboardCommand { get; }
        public double Value { get; set; }

        public UnitMenuPageViewModel()
        {
            BackCommand = new Command(BackButtonClicked);
            QuizCommand = new Command(QuizButtonClicked);
            FlashcardCommand = new Command(FlashcardButtonClicked);
            ChatCommand = new Command(ChatButtonClicked);
            LeaderboardCommand = new Command(LeaderboardButtonClicked);
            Value = 0.4; //The progress bar value is retrieved from the students' attendance as well, we cannot implement the calculation for now
        }

        private async void BackButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(MainPage)}");
        }
        private async void QuizButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(QuizMainPage)}");
        }
        private async void FlashcardButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(Flashcard)}");
        }
        private async void ChatButtonClicked(object obj)
        {
            await Xamarin.Forms.Application.Current.MainPage.DisplayAlert("Chat Feature", "This feature is currently not available", "Ok");
        }
        private async void LeaderboardButtonClicked(object obj)
        {
            await Xamarin.Forms.Application.Current.MainPage.DisplayAlert("Leaderboard Feature", "This feature is currently not available", "Ok");
        }
    }
}
