﻿using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Jason
    class UnitAddModalPageViewModel : BaseViewModel
    {
        public Command CloseCommand { get; }
        public Command JoinCommand { get; }
        private string _groupId;
        public string GroupId
        {
            get 
            {
                return _groupId; 
            }
            set
            {
                SetProperty(ref _groupId, value);
            }
        }


        public UnitAddModalPageViewModel()
        {
            CloseCommand = new Command(CloseButtonClicked);
            JoinCommand = new Command(JoinButtonClicked);
        }

        private async void CloseButtonClicked(object obj)
        {
            await Application.Current.MainPage.Navigation.PopModalAsync();
        }
       private async void JoinButtonClicked(object obj)
        {
            //Currently user cannot join any group because the group id is retrieved from group chat feature and that feature is currently not available
            if(string.IsNullOrWhiteSpace(GroupId) == false)
            {
                await Application.Current.MainPage.DisplayAlert("Invalid Group ID", "Please enter the valid GroupID", "Ok");
            }
            else
            {
                await Application.Current.MainPage.DisplayAlert("NULL Value", "You have to enter the Group ID", "Ok");
            }
        }
    }
}
