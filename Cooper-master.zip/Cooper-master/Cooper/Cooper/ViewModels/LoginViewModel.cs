﻿using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Jason
    public class LoginViewModel : BaseViewModel
    {
        public Command LoginCommand { get; }

        public LoginViewModel()
        {
            LoginCommand = new Command(OnLoginClicked);
        }

        private async void OnLoginClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(MainPage)}");
        }
    }
}
