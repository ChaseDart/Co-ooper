﻿using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using SkiaSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Arin & Jason
    [QueryProperty("UserAnswerCount", "useranswercount")]
    [QueryProperty("Week", "Weekid")]
    class QuizResultViewModel : BaseViewModel
    {
        public IDataStore<WeekQuizStatus> quizdataStore = (IDataStore<WeekQuizStatus>)DependencyService.Get<IDataStore<WeekQuizStatus>>();
        private double QuestionLimitation = 5;

        private string _week;

        public Command QuizDone { get; }
        public string Week
        {
            get
            {
                return _week;
            }
            set
            {
                SetProperty(ref _week, Uri.UnescapeDataString(value));
                OnPropertyChanged(Week);
            }
        }


        private string _useranswercount;
        private double useranswercount;
        public string UserAnswerCount
        {
            get
            {
                return _useranswercount;
            }
            set
            {
                SetProperty(ref _useranswercount, Uri.UnescapeDataString(value));

                useranswercount = double.Parse(_useranswercount);
                SetScore();
                CalculatePercent();

            }
        }

        public string Score
        {
            get; set;
        }

        public void SetScore()
        {
            Score = useranswercount + " / " + QuestionLimitation.ToString();
            OnPropertyChanged("Score");
        }

        public string PercentScore
        {
            get; set;
        }

        public void CalculatePercent()
        {
            double temp = (useranswercount / QuestionLimitation) * 100;
            int percent = (int)Math.Round(temp);
            PercentScore = percent.ToString() + " %";
            ProgressValue = percent;

            OnPropertyChanged("PercentScore");

        }

        private double _ProgressValue;
        public double ProgressValue
        {
            get
            {
                return _ProgressValue;
            }
            set
            {
                _ProgressValue = value;
                OnPropertyChanged();
            }
        }

        public QuizResultViewModel()
        {
            SetScore();
            CalculatePercent();
            ProgressValue = 0;
            QuizDone = new Command(MainButtonClicked);
        }

        private async void MainButtonClicked(object obj)
        {
            string temp = _week.Replace("WEEK ", "");
            int week = int.Parse(temp);
            await quizdataStore.UpdateItemAsync(week, "Done");
            await Shell.Current.GoToAsync($"//{nameof(QuizMainPage)}");

        }
    }
}
