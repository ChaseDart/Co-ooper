﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Ryuta
    
    [QueryProperty("QuestionNumber", "questionNumber")]
    [QueryProperty("Week", "Weekid")]
    class QuizHistoryPageViewModel : BaseViewModel
    {
        public IDataStore<Models.Flashcard> flahscarddataStore = (IDataStore<Models.Flashcard>)DependencyService.Get<IDataStore<Models.Flashcard>>();
        public int currentIndex { get; set; }
        public int LastIndex { get; set; }
        public int TotalNum { get; set; }
        public int Number { get; set; }
        public string Question { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string Answer { get; set; }
        public string Type { get; set; }
        public bool OptionA_Checked { get; set; }
        public bool OptionB_Checked { get; set; }
        public bool OptionC_Checked { get; set; }
        public bool OptionD_Checked { get; set; }
        public bool OptionA_Radio_Checked { get; set; }
        public bool OptionB_Radio_Checked { get; set; }
        public bool Firstest { get; set; }
        public bool Lastest { get; set; }
        public int NumberOfQuestions = 3;
        private string _week;
        private string _questionNumber;
        private int int_userAnswer;
        public int week { get; set; }
        public int totoal { get; set; }
        public string donne { get; set; }
        public bool RadioQuizCommand
        {
            get; set;

        }
        public bool TnFQuizCommand
        {
            get; set;
        }
        public bool ShortAnswerQuizCommand
        {
            get; set;
        }
        private Task<Quiz> Quiz;
        private Task<List<Quiz>> quizs;

        public Command BackCommand { get; }

    public Command GoQuizCommand { get; }

    public Command NextPage { get; }
    public Command AddCommand { get; }
    public Command PreviousPage { get; }

    public QuizHistoryPageViewModel()
    {
        BackCommand = new Command(BackButtonClicked);
        NextPage = new Command(NextPageButtonClicked);
        PreviousPage = new Command(PreviousPageButtonClicked);
        AddCommand = new Command(AddbuttonClicked);
    }
    public string QuestionNumber
    {
        get
        {
            return _questionNumber;
        }
        set
        {
            SetProperty(ref _questionNumber, Uri.UnescapeDataString(value));
        }
    }
    public string Week
    {
        get
        {
            //Console.WriteLine(_week);
            return _week;
        }
        set
        {
            SetProperty(ref _week, Uri.UnescapeDataString(value));
            string temp = _week.Replace("WEEK ", "");
            currentIndex = int.Parse(QuestionNumber);
            week = int.Parse(temp);
            Quiz = base.DataStore.GetItemAsync(week, int.Parse(QuestionNumber));
            quizs = base.DataStore.GetItemsAsync(week);
            foreach(Quiz quiz in quizs.Result)
            {
                LastIndex++;
            }
            
            SetupQuestion();
            
            
        }
    }

    public async void AddbuttonClicked(Object ob)
    {
        bool newresult = await Application.Current.MainPage.DisplayAlert("Save as a FlashCard?", " ", "Yes", "No");
        if (newresult == true)
        {   //save data to mockdata/database
            Console.WriteLine("Adding");
            Models.Flashcard alreadyInFlashcard = flahscarddataStore.GetItemAsync(week, int.Parse(QuestionNumber)).Result;
            if (alreadyInFlashcard == null)
            {
                Models.Flashcard newone = new Models.Flashcard
                {
                    Week = week,
                    Number = currentIndex,
                    Question = Question,
                    Answer = Answer,
                    OptionA = OptionA,
                    OptionB = OptionB,
                    OptionC = OptionC,
                    OptionD = OptionD
                };
                await flahscarddataStore.AddItemAsync(newone);
                await Application.Current.MainPage.DisplayAlert("Success!", " ", "OK");
            }
            else if (alreadyInFlashcard != null)
            {
                await Application.Current.MainPage.DisplayAlert("Already in flashcard!", " ", "OK");
            }
        }
    }

    private async void BackButtonClicked(object obj)
    {
        await Shell.Current.GoToAsync($"//{nameof(QuizMainPage)}");
    }
            
    private async void NextPageButtonClicked(object obj)
    {
        if (LastIndex != currentIndex)
        {
            LastIndex = 0;
            int temp1 = currentIndex + 1;
            Console.WriteLine(temp1);
            Console.WriteLine(LastIndex);
            await Shell.Current.GoToAsync($"//{nameof(QuizHistoryPage)}?Weekid={_week}&questionNumber={temp1}");

        }
    }
    private async void PreviousPageButtonClicked(object obj)
    {
        if (1 != currentIndex)
        {
            LastIndex = 0;
            int temp1 = currentIndex - 1;
            string temp = _week.Replace("WEEK ", "");
            int week = int.Parse(temp);
            await Shell.Current.GoToAsync($"//{nameof(QuizHistoryPage)}?Weekid={_week}&questionNumber={temp1}");

        }
    }
    public void SetupQuestion()
        {
            Type = Quiz.Result.Type;
            Number = Quiz.Result.Number;
            Question = Quiz.Result.Question;
            OptionA = Quiz.Result.OptionA;
            OptionB = Quiz.Result.OptionB;
            OptionC = Quiz.Result.OptionC;
            OptionD = Quiz.Result.OptionD;
            Answer = Quiz.Result.Answer;
            TotalNum = NumberOfQuestions;
            
            if (Type == "Multiple Choice")
            {
                RadioQuizCommand = true;
            }
            else if (Type != "Multiple Choice")
            {
                RadioQuizCommand = false;
            }

            if (Type == "True and False")
            {
                TnFQuizCommand = true;
            }
            else if (Type != "True and False")
            {
                TnFQuizCommand = false;
            }

            if (Type == "Short Answer")
            {
                ShortAnswerQuizCommand = true;
            }
            else if (Type != "Short Answer")
            {
                ShortAnswerQuizCommand = false;
            }
            if (Answer == "A" && RadioQuizCommand == true)
            {
                OptionA_Checked = true;
            }
            else if (Answer == "B" && TnFQuizCommand == true)
            {
                OptionB_Radio_Checked = true;
            }
            else if (Answer == "A" && TnFQuizCommand == true)
            {
                OptionA_Radio_Checked = true;
            }
            else if (Answer == "B" && RadioQuizCommand == true)
            {
                OptionB_Checked = true;
            }
            else if (Answer == "C")
            {
                OptionC_Checked = true;
            }
            else if (Answer == "D")
            {
                OptionD_Checked = true;
            }

            if (currentIndex == LastIndex)
            {
                Lastest = false;
            }
            else if (currentIndex != LastIndex)
            {
                Lastest = true;
            }
            if (currentIndex == 1)
            {
                Firstest = false;
            }
            else if (currentIndex != 1)
            {
                Firstest = true;
            }
            Console.WriteLine(OptionB_Checked);
            OnPropertyChanged("Lastest");
            OnPropertyChanged("Firstest");
            OnPropertyChanged("Question");
            OnPropertyChanged("Number");
            OnPropertyChanged("TotalNum");
            OnPropertyChanged("OptionA");
            OnPropertyChanged("OptionB");
            OnPropertyChanged("OptionC");
            OnPropertyChanged("OptionD");
            OnPropertyChanged("OptionA_Checked");
            OnPropertyChanged("OptionB_Checked");
            OnPropertyChanged("OptionA_Radio_Checked");
            OnPropertyChanged("OptionB_Radio_Checked");
            OnPropertyChanged("OptionC_Checked");
            OnPropertyChanged("OptionD_Checked");
            OnPropertyChanged("RadioQuizCommand");
            OnPropertyChanged("TnFQuizCommand");
            OnPropertyChanged("ShortAnswerQuizCommand");

        }
    }
}
