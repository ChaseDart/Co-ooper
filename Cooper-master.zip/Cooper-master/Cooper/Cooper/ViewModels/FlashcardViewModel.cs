﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Ryuta
    public class FlashcardViewModel
    {
        public IDataStore<Models.Flashcard> flahscarddataStore = (IDataStore<Models.Flashcard>)DependencyService.Get<IDataStore<Models.Flashcard>>();

        public List<FlashcardQuizWeek> FlashcardWeek { get; set; }
        public Command BackCommand { get; }
        public Command<string> Goweek3 { get; }
        public string week { get; set; }

        public FlashcardViewModel()
        {
            FlashcardWeek = new FlashcardQuizWeekService().GetFlashcardQuizWeekList();
            BackCommand = new Command(BackButtonClicked);
            Goweek3 = new Command<string>(WeekThreeButtonClicked);
        }
        private async void BackButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(UnitMenuPage)}");
        }
        private async void WeekThreeButtonClicked(string j)
        {
            week = "WEEK "+ j;

            string temp = week.Replace("WEEK ", "");

            int weekl = int.Parse(temp);

            Task<List<Models.Flashcard>> quizs = flahscarddataStore.GetItemsAsync(weekl);
            if (quizs.Result.Count == 0)
            {
                await Application.Current.MainPage.DisplayAlert("No flashcard!", " ", "OK");
                await Shell.Current.GoToAsync($"//{nameof(Views.Flashcard)}");
            }
            else
            {
                string questionNumber = quizs.Result[0].Number.ToString();
                
                await Shell.Current.GoToAsync($"//{nameof(FlashCardMain)}?Weekid={week}&questionNumber={questionNumber}");
                
            }

        }
    }
}
