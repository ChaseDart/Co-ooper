﻿using Cooper.Models;
using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Arin & Jason
    [QueryProperty("QuestionNumber", "questionNumber")]
    [QueryProperty("Week", "Weekid")]
    [QueryProperty("UserAnswerCount", "useranswercount")]
    class BaseQuizPageViewModel : BaseViewModel
    {
        // Data
        public int Number { get; set; }
        public string Question { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string Answer { get; set; }
        public string Type { get; set; }
        public bool OptionA_Checked { get; set; }
        public bool OptionB_Checked { get; set; }
        public bool OptionC_Checked { get; set; }
        public bool OptionD_Checked { get; set; }

        private string _useranswercount;
        public string UserAnswerCount {
            get
            {
                return _useranswercount;
            }
            set
            {
                SetProperty(ref _useranswercount, Uri.UnescapeDataString(value));
            }
        }

        public int NumberOfQuestions = 5;
        private string _duration;
        private string _week;
        private string _questionNumber;
        private int int_userAnswer;

        private Task<Quiz> Quiz;

        public string QuestionNumber { 
            get 
            {
                return _questionNumber;
            }
            set 
            {
                SetProperty(ref _questionNumber, Uri.UnescapeDataString(value));
            } 
        }
        public string Week
        {
            get
            {
                return _week;
            }
            set
            {
                SetProperty(ref _week, Uri.UnescapeDataString(value));
                string temp = _week.Replace("WEEK ", "");
                int week = int.Parse(temp);
                Quiz = DataStore.GetItemAsync(week, int.Parse(QuestionNumber));
                SetupQuestion();
            }
        }

        private string _input;
        public string Input
        {
            get
            {
                return _input;
            }
            set
            {
                _input = value;
                OnPropertyChanged();
            }
        }

        public bool RadioQuizCommand
        {
            get; set;

        }
        public bool TnFQuizCommand
        {
            get; set;
        }
        public bool ShortAnswerQuizCommand
        {
            get; set;
        }

        private double _ProgressValue;
        public double ProgressValue
        {
            get
            {
                return _ProgressValue;
            }
            set
            {
                _ProgressValue = value;
                OnPropertyChanged();
            }
        }
        
        public int GetUserAnswer()
        {
            int_userAnswer = int.Parse(UserAnswerCount);
            string temp_answer = "";
            if (OptionA_Checked)
            {
                temp_answer = "A";
            }
            if (OptionB_Checked)
            {
                temp_answer = "B";
            }
            if (OptionC_Checked)
            {
                temp_answer = "C";
            }
            if (OptionD_Checked)
            {
                temp_answer = "D";
            }
            if (Type == "Short Answer")
            {
                if(string.IsNullOrWhiteSpace(Input) == false)
                {
                    temp_answer = Input.ToLower();
                }
                else
                {
                    temp_answer = "";
                }
            }

            CountScore(temp_answer);

            return int_userAnswer;
        }

        private void CountScore(string temp_Answer)
        {
            if (CheckCorrectOrNot(temp_Answer) == true)
            {
                int_userAnswer++;
            }
        }

        private bool CheckCorrectOrNot(string input)
        {
            return (input == Answer);
        }
        public void OnStartTimerExecute()
        {
            Device.StartTimer(TimeSpan.FromSeconds(1), (() =>
            {
                if (StartTime.TotalSeconds > 1)
                {
                    StartTime = StartTime - TimeSpan.FromSeconds(1);
                    Duration = StartTime.ToString(@"ss");
                    ProgressValue--;
                    return true;

                }
                else
                {
                    GetUserAnswer();

                    if (int.Parse(QuestionNumber) < NumberOfQuestions)
                    {
                        int tempNumber = int.Parse(QuestionNumber);
                        tempNumber++;
                        string questionNumber = tempNumber.ToString();
                        
                        Shell.Current.GoToAsync($"//{nameof(BaseQuizPage)}?Weekid={Week}&questionNumber={questionNumber}" +
                            $"&useranswercount={int_userAnswer}");
                        OnStartTimerExecute();
                        StartTime = TimeSpan.FromSeconds(10);
                        Duration = StartTime.ToString(@"ss");
                        ProgressValue = 10;
                    }
                    else
                    {
                        GoResult();
                    }

                    return false;
                }
                
            }));
        }

        public async void GoResult()
        {
            string week = Week;
            await Shell.Current.GoToAsync($"//{nameof(QuizResultPage)}?Weekid={week}&useranswercount={int_userAnswer}");
        }
        public TimeSpan StartTime { get; set; }
        public string Duration
        {
            get { return _duration; }
            set
            {
                _duration = value;
                OnPropertyChanged();
            }
        }

        public string wknum;
        public void WeekNumber()
        {
            wknum = _week;
        }
        public BaseQuizPageViewModel()
        {
            
            OnStartTimerExecute();
            StartTime = TimeSpan.FromSeconds(10);
            Duration = StartTime.ToString(@"ss");
            ProgressValue = 10;
        }

        public void SetupQuestion()
        {
            Type = Quiz.Result.Type;
            Number = Quiz.Result.Number;
            Question = Quiz.Result.Question;
            OptionA = Quiz.Result.OptionA;
            OptionB = Quiz.Result.OptionB;
            OptionC = Quiz.Result.OptionC;
            OptionD = Quiz.Result.OptionD;
            Answer = Quiz.Result.Answer;
            OptionA_Checked = false;
            OptionB_Checked = false;
            OptionC_Checked = false;
            OptionD_Checked = false;


            if (Type == "Multiple Choice")
            {
                RadioQuizCommand = true;
            }
            else
            {
                RadioQuizCommand = false;
            }

            if (Type == "True and False")
            {
                TnFQuizCommand = true;
            }
            else
            {
                TnFQuizCommand = false;
            }

            if (Type == "Short Answer")
            {
                ShortAnswerQuizCommand = true;
            }
            else
            {
                ShortAnswerQuizCommand = false;
            }

            OnPropertyChanged("Question");
            OnPropertyChanged("Number");
            OnPropertyChanged("OptionA");
            OnPropertyChanged("OptionB");
            OnPropertyChanged("OptionC");
            OnPropertyChanged("OptionD");
            OnPropertyChanged("RadioQuizCommand");
            OnPropertyChanged("TnFQuizCommand");
            OnPropertyChanged("ShortAnswerQuizCommand");
            OnPropertyChanged("Checked");
            OnPropertyChanged("OptionA_Checked");
            OnPropertyChanged("OptionB_Checked");
            OnPropertyChanged("OptionC_Checked");
            OnPropertyChanged("OptionD_Checked");

        }

    }
}
