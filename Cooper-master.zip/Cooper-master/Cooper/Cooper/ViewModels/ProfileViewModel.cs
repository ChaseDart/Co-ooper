﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ProgressRingControl.Forms.Plugin;
using Cooper.Models;
using Cooper.ViewModels;

using ChartEntry = Microcharts.ChartEntry;
using SkiaSharp;
using Microcharts;
using System.Windows.Input;
using Cooper.Services;
using System.Security.Cryptography.X509Certificates;
using Cooper.Views;

namespace Cooper.ViewModels
{
    //Done by Chase
    class Callit
    {
        public static String HexConverter(System.Drawing.Color c)
        {
            return "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
        }
        public static double ToPercent(double classTotal, double userTotal)
        {
            return userTotal / classTotal;
        }

        static public List<UserLogData> SortDescending(List<UserLogData> list)
        {
            list.Sort((a, b) => b.DatesLogged.CompareTo(a.DatesLogged));
            return list;
        }
        static public List<UserLogData> SortAscending(List<UserLogData> list)
        {
            list.Sort((a, b) => a.DatesLogged.CompareTo(b.DatesLogged));
            return list;
        }
    }

    class ProfilePageViewModel
    {
        public List<ChartEntry> weeklyChartEntries(List<UserLogData> UserLogData)
        {
            List<ChartEntry> userWeekChartEntry = new List<ChartEntry>();
            DateTime d1 = new DateTime(2020, 10, 13, 23, 59, 59);
            //d1 = d1.AddDays(-14);
            int j = 0;
            int q = 7;
            int i = 0;
            while (i < q)
            {

                if (UserLogData[i - j].DatesLogged.Date > d1.Date)
                {
                    q++;
                    i++;
                    continue;
                }
                if (UserLogData[i - j].DatesLogged.Date < d1.Date)
                {
                    userWeekChartEntry.Add(new ChartEntry(5)
                    {
                        Color = SKColor.Parse(Callit.HexConverter(Color.FromRgb(230, 230, 255))),
                        Label = d1.ToString("dddd"),
                        ValueLabel = "0 Hr"
                    });
                    j++;

                }
                else if (UserLogData[i - j].DatesLogged.Date == d1.Date)
                {
                    double barColor = (double)UserLogData[i - j].TimeSpent / 181;
                    double newBarColor = (barColor * 255);

                    userWeekChartEntry.Add(new ChartEntry(UserLogData[i - j].TimeSpent)
                    {
                        Color = SKColor.Parse(Callit.HexConverter(Color.FromRgb(255 - (int)newBarColor, 255 - (int)newBarColor, 255))),
                        Label = d1.ToString("dddd"),
                        ValueLabel = Convert.ToString(UserLogData[i - j].TimeSpent / (int)60) + " Hr " + Convert.ToString(UserLogData[i - j].TimeSpent % 60) + " Min"
                    });
                }

                i++;
                d1 = d1.AddDays(-1);
            }
            return userWeekChartEntry;
        }



        public userProfile userProfile1 { get; set; }
        public BarChart userChart { get; set; }
        public string[] ClassScore { get; set; }
        public double[] ClassScoreD { get; set; }
        public string[] ClassName { get; set; }
        public string StudentName { get; set; }
        public string StudentNum { get; set; }
        public string StudentDes { get; set; }
        public string StudentStar { get; set; }
        public string StudentMoney { get; set; }
        public Command BacktoMenuCommand { get; }

        public ProfilePageViewModel()
        {
            ClassScore = new string[4];
            ClassScoreD = new double[4];
            ClassName = new string[4];

            userProfile userProfile = ClassMockStorageData.NewAttempt();

            userProfile.UserLogData = Callit.SortDescending(userProfile.data);

            userProfile.userWeekChartEntry = weeklyChartEntries(userProfile.UserLogData);

            userChart = new BarChart { Entries = userProfile.userWeekChartEntry };

            

            StudentName = userProfile.userName;
            StudentDes = userProfile.userBio;
            StudentNum = userProfile.userStudentNumber;
            StudentMoney = userProfile.Money;
            StudentStar = userProfile.Stars;

            ClassScore[0] = userProfile.ClassMockData[0].UserTotal.ToString() + " / " + userProfile.ClassMockData[0].ClassTotal.ToString();
            ClassScoreD[0] = Callit.ToPercent(userProfile.ClassMockData[0].ClassTotal, userProfile.ClassMockData[0].UserTotal);
            ClassName[0] = userProfile.ClassMockData[0].ClassName;

            ClassScore[1] = userProfile.ClassMockData[1].UserTotal.ToString() + " / " + userProfile.ClassMockData[1].ClassTotal.ToString();
            ClassScoreD[1] = Callit.ToPercent(userProfile.ClassMockData[1].ClassTotal, userProfile.ClassMockData[1].UserTotal);
            ClassName[1] = userProfile.ClassMockData[1].ClassName;

            ClassScore[2] = userProfile.ClassMockData[2].UserTotal.ToString() + " / " + userProfile.ClassMockData[2].ClassTotal.ToString();
            ClassScoreD[2] = Callit.ToPercent(userProfile.ClassMockData[2].ClassTotal, userProfile.ClassMockData[2].UserTotal);
            ClassName[2] = userProfile.ClassMockData[2].ClassName;

            ClassScore[3] = userProfile.ClassMockData[3].UserTotal.ToString() + " / " + userProfile.ClassMockData[3].ClassTotal.ToString();
            ClassScoreD[3] = Callit.ToPercent(userProfile.ClassMockData[3].ClassTotal, userProfile.ClassMockData[3].UserTotal);
            ClassName[3] = userProfile.ClassMockData[3].ClassName;

            userProfile1 = userProfile;
            BacktoMenuCommand = new Command(BacktoMenuClicked);

        }
        private async void BacktoMenuClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(MainPage)}");
        }
    }

}
