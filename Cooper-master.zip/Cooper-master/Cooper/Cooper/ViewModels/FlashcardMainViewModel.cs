﻿using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Ryuta
    [QueryProperty("QuestionNumber", "questionNumber")]
    [QueryProperty("Week", "Weekid")]
    class FlashcardMainViewModel : BaseViewModel
    {
        public IDataStore<Models.Flashcard> flahscarddataStore = (IDataStore<Models.Flashcard>)DependencyService.Get<IDataStore<Models.Flashcard>>();
        public int currentIndex { get; set; }
        public int LastIndex { get; set; }
        public int TotalNum { get; set; }
        public int Number { get; set; }
        public string Question { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string Answer { get; set; }
        public string Type { get; set; }
        public bool OptionA_Checked { get; set; }
        public bool OptionB_Checked { get; set; }
        public bool OptionC_Checked { get; set; }
        public bool OptionD_Checked { get; set; }
        public bool Firstest { get; set; }
        public bool Lastest { get; set; }
        public int NumberOfQuestions { get; set; }
        private string _week;
        private string _questionNumber;
        private int int_userAnswer;

        public bool RadioQuizCommand
        {
            get; set;

        }
        public bool TnFQuizCommand
        {
            get; set;
        }
        public bool ShortAnswerQuizCommand
        {
            get; set;
        }
        private Task<Models.Flashcard> Quiz;
        private Task<List<Models.Flashcard>> quizs;
        public bool flipped = false;
        public Command BackCommand { get; }

        public Command flipCommand { get; }

        public Command DeleteCommand { get; }

        public Command NextPage { get; }

        public Command PreviousPage { get; }


        public FlashcardMainViewModel()
        {
            BackCommand = new Command(BackButtonClicked);
            flipCommand = new Command(FlipButtonClicked);
            NextPage = new Command(NextPageButtonClicked);
            PreviousPage = new Command(PreviousPageButtonClicked);
            DeleteCommand = new Command(DelbuttonClicked);
        }
        public string QuestionNumber
        {
            get
            {
                return _questionNumber;
            }
            set
            {
                SetProperty(ref _questionNumber, Uri.UnescapeDataString(value));
            }
        }
        public string Week
        {
            get
            {
                //Console.WriteLine(_week);
                return _week;
            }
            set
            {


                SetProperty(ref _week, Uri.UnescapeDataString(value));
                //flahscarddataStore.UpdateItemAsync(1, "1");
                string temp = _week.Replace("WEEK ", "");

                int week = int.Parse(temp);

                 Quiz = flahscarddataStore.GetItemAsync(week, int.Parse(QuestionNumber));
                Console.WriteLine(Quiz.Result.Answer);
                quizs = flahscarddataStore.GetItemsAsync(week);

                NumberOfQuestions = quizs.Result.Count();
                LastIndex = NumberOfQuestions;
                int i = 0;
                currentIndex = 0;
                foreach (Models.Flashcard flashcard in quizs.Result)
                {
                    if (flashcard.Number == Quiz.Result.Number)
                    {
                        currentIndex = i;
                        break;
                    }
                    else { i ++; }
                    
                }
                SetupQuestion();
            }
        }

        private async void FlipButtonClicked(object obj)
        {
            if (flipped == false)
            {
                string correct_ans = Quiz.Result.Answer;
                if (correct_ans == "A")
                {
                    Question = Quiz.Result.OptionA;
                }
                if (correct_ans == "B")
                {
                    Question = Quiz.Result.OptionB;
                }

                if (correct_ans == "C")
                {
                    Question = Quiz.Result.OptionC;
                }
                if (correct_ans == "D")
                {
                    Question = Quiz.Result.OptionD;
                }
                OnPropertyChanged("Question");
                flipped = true;
            }
            else
            {
                Question = Quiz.Result.Question;
                OnPropertyChanged("Question");
                flipped = false;
            }

        }


        private async void BackButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(Views.Flashcard)}");
        }

        private async void NextPageButtonClicked(object obj)
        {
            if ((LastIndex - 1) != currentIndex)
            {
                currentIndex ++;
                int nextone = quizs.Result[currentIndex].Number;
                await Shell.Current.GoToAsync($"//{nameof(FlashCardMain)}?Weekid={_week}&questionNumber={nextone}");

            }
        }
        private async void PreviousPageButtonClicked(object obj)
        {
            if (0 != currentIndex)
            {
                currentIndex --;
                int nextone = quizs.Result[currentIndex].Number;
                await Shell.Current.GoToAsync($"//{nameof(FlashCardMain)}?Weekid={_week}&questionNumber={nextone}");

            }
        }


        public async void DelbuttonClicked(Object ob)
        {
            bool newresult = await Application.Current.MainPage.DisplayAlert("Delete a FlashCard?", " ", "Yes", "No");
            if (newresult == true)
            {   //save data to mockdata/database
                Console.WriteLine("Deleting");
                string temp = _week.Replace("WEEK ", "");
                int week = int.Parse(temp);
                int tempone = Quiz.Result.Number;
                await flahscarddataStore.DeleteItemAsync(week, tempone);
                int newone1 = 0;
                if (currentIndex == 0)
                {
                    newone1 = currentIndex + 1;
                }
                else
                {
                    newone1 = currentIndex - 1;
                }

                int currenttot = NumberOfQuestions - 1;
                if (currenttot == 0) 
                {
                    await Application.Current.MainPage.DisplayAlert("No flashcard!", " ", "OK");
                    await Shell.Current.GoToAsync($"//{nameof(Views.Flashcard)}");
                }
                else
                {
                    int upadatedone = quizs.Result[newone1].Number;
                    await Shell.Current.GoToAsync($"//{nameof(FlashCardMain)}?Weekid={_week}&questionNumber={upadatedone}");
                    await Application.Current.MainPage.DisplayAlert("Success to delete!", " ", "OK");
                }
            }
            else
            {

            }

        }
        public void SetupQuestion()
        {
            Number = Quiz.Result.Number;
            Question = Quiz.Result.Question;
            OptionA = Quiz.Result.OptionA;
            OptionB = Quiz.Result.OptionB;
            OptionC = Quiz.Result.OptionC;
            OptionD = Quiz.Result.OptionD;
            Answer = Quiz.Result.Answer;
            TotalNum = NumberOfQuestions;

            if (Answer == "A")
            {
                OptionA_Checked = true;
            }
            else
            {
                OptionA_Checked = true;

            }
            if (Answer == "B")
            {
                OptionB_Checked = true;
            }
            else
            {
                OptionB_Checked = false;

            }
            if (Answer == "C")
            {
                OptionC_Checked = true;
            }
            else
            {
                OptionC_Checked = false;

            }
            if (Answer == "D")
            {
                OptionD_Checked = true;
            }
            else
            {
                OptionD_Checked = false;

            }


            if (Type == "Multiple Choice")
            {
                RadioQuizCommand = true;
            }
            else
            {
                RadioQuizCommand = false;
            }

            if (Type == "True and False")
            {
                TnFQuizCommand = true;
            }
            else
            {
                TnFQuizCommand = false;
            }

            if (Type == "Short Answer")
            {
                ShortAnswerQuizCommand = true;
            }
            else
            {
                ShortAnswerQuizCommand = false;
            }

            if (currentIndex == ( LastIndex - 1))
            {
                Lastest = false;
            }
            else if (currentIndex != (LastIndex - 1))
            {
                Lastest = true;
            }
            if (currentIndex == 0)
            {
                Firstest = false;
            }
            else if (currentIndex != 0)
            {
                Firstest = true;
            }
            OnPropertyChanged("Question");
            OnPropertyChanged("Number");
            OnPropertyChanged("TotalNum");
            OnPropertyChanged("OptionA");
            OnPropertyChanged("OptionB");
            OnPropertyChanged("OptionC");
            OnPropertyChanged("OptionD");
            OnPropertyChanged("RadioQuizCommand");
            OnPropertyChanged("TnFQuizCommand");
            OnPropertyChanged("ShortAnswerQuizCommand");
            OnPropertyChanged("Checked");
            OnPropertyChanged("OptionA_Checked");
            OnPropertyChanged("OptionB_Checked");
            OnPropertyChanged("OptionC_Checked");
            OnPropertyChanged("OptionD_Checked");
            OnPropertyChanged("Lastest");
            OnPropertyChanged("Firstest");

        }
    }
}
