﻿using Cooper.Models;
using Cooper.Services;
using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Arin & Jason
    class QuizMainPageViewModel : BaseViewModel
    {
        public IDataStore<WeekQuizStatus> nedatabase = (IDataStore<WeekQuizStatus>)DependencyService.Get<IDataStore<WeekQuizStatus>>();
        public Command BackCommand { get; }
        public Command<string> GotoQuiz { get; }

       
        public int onceattempt;

        public string week;
        public int currentWeek = 7;

        public QuizMainPageViewModel()
        {
            BackCommand = new Command(BackButtonClicked);
            GotoQuiz = new Command<string>(Week2ButtonClicked);

        }

        private async void BackButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(UnitMenuPage)}");
        }
        private async void EmptyButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(QuizMainPage)}");
        }
        private async void Week2ButtonClicked(string i)
        {
            week = "WEEK " + i;

            
            if (int.Parse(i) > currentWeek)
            {
                
                await Application.Current.MainPage.DisplayAlert(week, "This quiz is not available", "Ok");
            }
            else if ( int.Parse(i) < currentWeek)
            {

                await Shell.Current.GoToAsync($"//{nameof(QuizHistoryPage)}?Weekid={week}&questionNumber={1}");
            }
            else
            {
                WeekQuizStatus newone = nedatabase.GetItemAsync(int.Parse(i), 1).Result;
                if (newone.IsCompleted == "Done")
                {
                    await Shell.Current.GoToAsync($"//{nameof(QuizHistoryPage)}?Weekid={week}&questionNumber={1}");
                }
                else
                {
                    await Shell.Current.GoToAsync($"//{nameof(QuizStartingPage)}?Weekid={week}");
                }
                
            }
            
        }
    }
}
