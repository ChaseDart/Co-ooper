﻿using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Arin & Jason
    [QueryProperty("Week", "Weekid")]
    class QuizStartCountdownViewModel : BaseViewModel
    {
        private string _duration;
        private string _week;
        public string Week {
            get
            {
                return _week;
            }
            set 
            {
                SetProperty(ref _week, Uri.UnescapeDataString(value));
            } }

        private double _ProgressValue;
        public double ProgressValue
        {
            get
            {
                return _ProgressValue;
            }
            set
            {
                _ProgressValue = value;
                OnPropertyChanged();
            }
        }
        public void OnStartTimerExecute()
        {
            Device.StartTimer(TimeSpan.FromSeconds(1), (() =>
            {
                if (StartTime.TotalSeconds > 1)
                {
                    StartTime = StartTime - TimeSpan.FromSeconds(1);
                    Duration = StartTime.ToString(@"ss");
                    ProgressValue--;
                    return true;
                }
                else
                {
                    NextPage();
                    return false;
                }
            }));
        }
        public TimeSpan StartTime { get; set; }
        public string Duration
        {
            get { return _duration; }
            set
            {
                _duration = value;
                OnPropertyChanged();
            }
        }
        public QuizStartCountdownViewModel()
        {
            OnStartTimerExecute();
            StartTime = TimeSpan.FromSeconds(5);
            Duration = StartTime.ToString(@"ss");
            ProgressValue = 5;
        }
        private async void NextPage()
        {
            string questionNumber = "1";
            string useranswercount = "0";
            await Shell.Current.GoToAsync($"//{nameof(BaseQuizPage)}?Weekid={_week}&questionNumber={questionNumber}&useranswercount={useranswercount}");
        } 

    }
}
