﻿using Cooper.Views;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cooper.ViewModels
{
    //Done by Arin & Jason
    [QueryProperty("Week", "Weekid")]
    class QuizStartingPageViewModel : BaseViewModel
    {
        private string _week;
        public string Week
        {
            get
            {
                return _week;
            }
            set
            {
                SetProperty(ref _week, Uri.UnescapeDataString(value));
            }
        }
        public Command StartCommand { get; }
        public Command MainCommand { get; }

        public QuizStartingPageViewModel()
        {
            StartCommand = new Command(StartButtonClicked);
            MainCommand = new Command(MainButtonClicked);
        }

        private async void MainButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(QuizMainPage)}");
        }

        private async void StartButtonClicked(object obj)
        {
            await Shell.Current.GoToAsync($"//{nameof(QuizStartCountdown)}?Weekid={_week}");
        }
    }
}
