﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cooper
{
    class StartTimerValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            //5 sec is max time
            return (double)value / 5;

        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return new NotImplementedException();
        }
    }
}
