﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cooper.Models;

namespace Cooper.Services
{
    //Done by Ryuta
    public class FlashcardQuizWeekService
    {
        public List<FlashcardQuizWeek> flashcardQuizWeeks;
        public List<FlashcardQuizWeek> GetFlashcardQuizWeekList()
        {
            return new List<FlashcardQuizWeek>()
            {
                new FlashcardQuizWeek(){ Title="Week1"},

                new FlashcardQuizWeek(){ Title="Week3"},

                new FlashcardQuizWeek(){ Title="Week4"},

                new FlashcardQuizWeek(){ Title="Week6"},
            };
        }
        public async Task<bool> UpdateItemAsync(FlashcardQuizWeek item)
        {
            flashcardQuizWeeks.Add(item);
            return await Task.FromResult(true);
        }
    }
}
