﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cooper.Models;

namespace Cooper.Services
{
    //Done by Jason
    public class MockUnitDataStore
    {
        public List<Units> unitItems;
        public MockUnitDataStore()
        {
            unitItems = new List<Units>()
            {
                new Units(){ UnitName="IAB330"},

                new Units(){ UnitName="CAB303"},

                new Units(){ UnitName="EGB339"},

            };

        }

        public List<Units> GetUnitsNameList()
        {
            return unitItems;
        }

    }
}
