﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cooper.Models;
using SQLite;

namespace Cooper.Services
{
    //Done by Ryuta
    public class FlashCardsDataStore : IDataStore<Flashcard>
    {
        readonly SQLiteAsyncConnection database = App.Database.Database;

        public async Task<bool> AddItemAsync(Flashcard item)
        {
            Console.WriteLine(item.Answer);
            return await database.InsertAsync(item) > 0;
        }

        public async Task<bool> DeleteItemAsync(int week, int number)
        {
            var items = database.Table<Flashcard>().FirstOrDefaultAsync(i => i.Week == week && i.Number == number);
            var para2 = week.ToString();
            var para3 = number.ToString();
            //return items != null && await database.DeleteAsync(items) > 0;
            database.QueryAsync<Flashcard>("DELETE FROM [Flashcard] WHERE [Week] = ? AND [Number] = ?", new string[2] { para2 ,para3 });
            return items != null;
        }

        public Task<Flashcard> GetItemAsync(int week, int number)
        {

            Console.WriteLine(week);

            var items = database.Table<Flashcard>().FirstOrDefaultAsync(i => i.Week == week && i.Number == number);
            return items;
        }

        public Task<List<Flashcard>> GetItemsAsync(int week, bool forceRefresh)
        {
            var para1 = week.ToString();
            return database.QueryAsync<Flashcard>("SELECT * FROM [Flashcard] WHERE [Week] = ?  ORDER BY [Number]", new string[1]{para1});
        }

        public async Task<bool> UpdateItemAsync(int index, string newone)
        {
            database.DropTableAsync<Flashcard>();
            return await database.CreateTableAsync<Flashcard>() > 0;
        }
    }
}
