﻿using Cooper.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cooper.Services
{
    //Done by Ryuta
    class MockFlashcardDataStore : IDataStore<Flashcard>
    {
        readonly List<Flashcard> flashcardItems;

        public MockFlashcardDataStore()
        {
            flashcardItems = new List<Flashcard>()
            {
                
            };
        }

        public async Task<bool> AddItemAsync(Flashcard item)
        {
            flashcardItems.Add(item);

            return await Task.FromResult(true);
        }

        public async Task<bool> DeleteItemAsync(int week, int number)
        {
            var oldFlashcard = flashcardItems.Where(y => y.Week == week).Where(y => y.Number == number);
            flashcardItems.Remove((Flashcard)oldFlashcard);

            return await Task.FromResult(true);
        }

        public async Task<Flashcard> GetItemAsync(int week, int number)
        {
            return await Task.FromResult(flashcardItems.FirstOrDefault(s => s.Week == week && s.Number == number));
        }

        public async Task<bool> UpdateItemAsync(int inde, string newone)
        {
            throw new NotImplementedException();
        }
        public async Task<List<Flashcard>> GetItemsAsync(int week, bool forceRefresh = false)
        {
            throw new NotImplementedException();
        }
    }
}
