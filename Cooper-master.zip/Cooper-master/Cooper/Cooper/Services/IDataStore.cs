﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cooper.Services
{
    public interface IDataStore<T>
    {
        Task<bool> AddItemAsync(T item);
        Task<bool> DeleteItemAsync(int week, int number);
        Task<T> GetItemAsync(int week, int number);
        Task<bool> UpdateItemAsync(int index, string newone);
        Task<List<T>> GetItemsAsync(int week, bool forceRefresh = false);
    }
}
