﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Cooper.Extentions;
using Cooper.Models;
using SQLite;

namespace Cooper.Services
{
    //Done by Ryuta
    public class AppDatabase
    {
        static readonly Lazy<SQLiteAsyncConnection> lazyInitializer = new Lazy<SQLiteAsyncConnection>(() =>
        {
            return new SQLiteAsyncConnection(Constants.DatabasePath, Constants.Flags);
        });

        public SQLiteAsyncConnection Database => lazyInitializer.Value;
        public SQLiteAsyncConnection newDatabase => lazyInitializer.Value;
        static bool initialized = false;

        public AppDatabase()
        {
            InitializeAsync().SafeFireAndForget(false);
        }

        async Task InitializeAsync()
        {
            if (!initialized)
            {
                if (!Database.TableMappings.Any(m => m.MappedType.Name == typeof(Flashcard).Name))
                {
                    await Database.CreateTablesAsync(CreateFlags.None, typeof(Flashcard)).ConfigureAwait(false);
                }
                if (!newDatabase.TableMappings.Any(m => m.MappedType.Name == typeof(WeekQuizStatus).Name))
                {
                    await newDatabase.CreateTablesAsync(CreateFlags.None, typeof(WeekQuizStatus)).ConfigureAwait(false);
                    var newstatus = new WeekQuizStatus() { Week = 7, IsCompleted = "NotDone" };
                    newDatabase.InsertAsync(newstatus);
                }
                initialized = true;
            }

        }
    }
}
