﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Cooper.Models;
using SQLite;

namespace Cooper.Services
{
    //Done by Jason & Ryuta
    public class QuizWeekStatusDatabase : IDataStore<WeekQuizStatus>
    {
        public QuizWeekStatusDatabase()
        {
        }
        readonly SQLiteAsyncConnection nedatabase = App.Database.newDatabase;

        public async Task<bool> AddItemAsync(WeekQuizStatus item)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteItemAsync(int week, int number)
        {
            throw new NotImplementedException();
        }

        public Task<WeekQuizStatus> GetItemAsync(int week, int number)
        {
            Console.WriteLine(week);

            var items = nedatabase.Table<WeekQuizStatus>().FirstOrDefaultAsync(i => i.Week == week);
            return items;
        }

        public Task<List<WeekQuizStatus>> GetItemsAsync(int week, bool forceRefresh = false)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> UpdateItemAsync(int week, string status)
        {
            WeekQuizStatus updatedWeek = new WeekQuizStatus
            {
                Week = week,
                IsCompleted = status
            };
            return await nedatabase.UpdateAsync(updatedWeek) > 0;
        }
    }
}
