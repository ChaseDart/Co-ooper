﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Cooper.Models;

namespace Cooper.Services
{
    //Done by Arin, Chase, Jason
    public class MockQuizDataStore : IDataStore<Quiz>
    {
        readonly List<Quiz> quizItems;
        public MockQuizDataStore()
        {
            quizItems = new List<Quiz>()
            {
                //Week 1
                new Quiz { Week = 1, Number = 1, Question = "What is not one of component of Design Cycle?",
                    OptionA = "Build Design Artifacts", OptionB = "Build Design Process", OptionC = "Evaluate", OptionD = "Scientific Theory & Methods", Answer = "D", Type = "Multiple Choice"},

                new Quiz { Week = 1, Number = 3, Question = "what is not the stage of process iteration?",
                    OptionA = "Problem Identification & Design Motivation", OptionB = "Competitor Analysis", OptionC = "Design Objectives", OptionD = "Build Class Diagram", Answer = "D", Type = "Multiple Choice"},

                new Quiz { Week = 1, Number = 2, Question = "When is the starting week of group formation for assignment 1?",
                    OptionA = "Week Fice", OptionB = "Week two", OptionC = "Week eig", OptionD = "No group assignment", Answer = "B", Type = "Multiple Choice"},

                new Quiz { Week = 1, Number = 4, Question = "Design science is fundamentally a problem-solving paradigm?",
                    OptionA = "True", OptionB = "False", Answer = "A", Type = "True and False"},

                //Week2
                new Quiz { Week = 2, Number = 1, Question = "Design science is fundamentally a problem-solving paradigm?",
                    OptionA = "True", OptionB = "False", Answer = "A", Type = "True and False"},

                new Quiz { Week = 2, Number = 2, Question = "What is not one of component of Design Cycle?",
                    OptionA = "Build Design Artifacts", OptionB = "Build Design Process", OptionC = "Evaluate", OptionD = "Scientific Theory & Methods", Answer = "D", Type = "Multiple Choice"},

                new Quiz { Week = 2, Number = 3, Question = "What is not the stage of process iteration?",
                    OptionA = "Problem Identification & Design Motivation", OptionB = "Competitor Analysis", OptionC = "Design Objectives", OptionD = "Build Class Diagram", Answer = "D", Type = "Multiple Choice"},

                new Quiz { Week = 2, Number = 4, Question = "When is the starting week of group formation for assignment 1?",
                    OptionA = "Week2", OptionB = "Week5", OptionC = "Week8", OptionD = "No group assignment", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 2, Number = 5, Question = "What programming language you use for this semester?",
                     Answer = "c#", Type = "Short Answer"},

                // Week 3
                new Quiz { Week = 3, Number = 1, Question = "A program that is employed in the development, repair or enhancement of other programs is known as",
                    OptionA = "Software Tool", OptionB = "System Software", OptionC = "Application program", OptionD = "Utility Program", Answer = "B", Type = "Multiple Choice"},

                new Quiz { Week = 3, Number = 2, Question = "A program that converts computer data into some code system other than the normal one is known as",
                    OptionA = "Encoder", OptionB = "Simulation", OptionC = "Emulator", OptionD = "Coding", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 3, Number = 3, Question = "A language which is close to that used within the computer is",
                    OptionA = "High level language", OptionB = "Assembly Language", OptionC = "Low-Level Language", OptionD = "All of the Above", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 3, Number = 4, Question = "A modern digital computer has",
                    OptionA = "Extemely High Speeds", OptionB = "Large Memory", OptionC = "Almost unlimited Array", OptionD = "All of the Above", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 3, Number = 5, Question = "Compilers and interpreters are themselves",
                    OptionA = "High Level Language", OptionB = "Codes", OptionC = "Programs", OptionD = "Mnemonics", Answer = "C", Type = "Multiple Choice"},

                // Week 4 - it has Short Answer Question
                new Quiz { Week = 4, Number = 1, Question = "What is not the example of cross platform Development Frameworks, Libraries, and Tool?",
                    OptionA = "Xamarin", OptionB = "Flutter", OptionC = "Visual Studio", OptionD = "Adobe PhoneGap", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 4, Number = 2, Question = "What is not one of component of Design Cycle?",
                    OptionA = "Trello", OptionB = "Slack", OptionC = "Messenger", OptionD = "No recommended", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 4, Number = 3, Question = "The binary system uses powers of",
                    OptionA = "2", OptionB = "10", OptionC = "8", OptionD = "16", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 4, Number = 4, Question = "A computer program that converts assembly language to machine language is",
                    OptionA = "Compiler", OptionB = "Interpreter", OptionC = "Assembler", OptionD = "Comparator", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 4, Number = 5, Question = "The time required for the fetching and execution of one simple machine instruction is",
                    OptionA = "Delay time", OptionB = "CPU Cycle", OptionC = "Real time", OptionD = "Seek Time", Answer = "B", Type = "Multiple Choice"},

                //Week 5
                new Quiz { Week = 5, Number = 1, Question = "Computer memory consists of",
                    OptionA = "RAM", OptionB = "ROM", OptionC = "PROM", OptionD = "All of the Above", Answer = "A", Type = "Mulitple Choice"},

                new Quiz { Week = 5, Number = 2, Question = "The organization and interconnection of the various components of a computer system is",
                    OptionA = "Architecture", OptionB = "Networks", OptionC = "Graphics", OptionD = "Designing", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 5, Number = 3, Question = "RAM is used as a short memory because it is",
                    OptionA = "Volatile", OptionB = "Is very expensive", OptionC = "Has a small Capacity", OptionD = "Is programmable", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 5, Number = 4, Question = "Which network is a packet switching network?",
                    OptionA = "Ring Network", OptionB = "LAN", OptionC = "Star Network", OptionD = "EuroNET", Answer = "D", Type = "Multiple Choice"},

                new Quiz { Week = 5, Number = 5, Question = "Which of the following is not currently a topic in computer science?",
                    OptionA = "Speech recognition", OptionB = "AI", OptionC = "Thermodynamics", OptionD = "Multiproccesing", Answer = "C", Type = "Multiple Choice"},


                //Week6
                new Quiz { Week = 6, Number = 1, Question = "What is App Development software which students will use in IAB330?",
                    OptionA = "Xamarin", OptionB = "Python", OptionC = "Marvel", OptionD = "UML", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 6, Number = 2, Question = "For 'C' programming language:",
                    OptionA = "Constant expressions are evaluated at compile", OptionB = "String constants can be concatenated at compile time", OptionC = "Size of array should be known at compile time", OptionD = "All of these", Answer = "D", Type = "Multiple Choice"},
                
                new Quiz { Week = 6, Number = 3, Question = "A web address is usually known as...",
                    OptionA = "URL", OptionB = "UWL", OptionC = "WWW", OptionD = "UVL", Answer = "A", Type = "Multiple Choice"},
                
                new Quiz { Week = 6, Number = 4, Question = "USB is a ………………………… storage device.",
                    OptionA = "Primary", OptionB = "Secondary", OptionC = "Auxilary", OptionD = "Additional", Answer = "B", Type = "Multiple Choice"},
                
                new Quiz { Week = 6, Number = 5, Question = "A computer assisted method for the recording and analyzing of existing or hypothetical systems is",
                    OptionA = "Data Transmission", OptionB = "Data Flow", OptionC = "Data Processing", OptionD = "Data Capture", Answer = "B", Type = "Multiple Choice"},
                

                //Week 7
                new Quiz { Week = 7, Number = 1, Question = "The process of communicating with a file from a terminal is",
                    Answer = "interrogation", Type = "Short Answer"},

                new Quiz { Week = 7, Number = 2, Question = "Which computer has been designed to be as compact as possible?",
                    OptionA = "Mini", OptionB = "Super Computer", OptionC = "Micro Computer", OptionD = "Mainframe", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 7, Number = 3, Question = "Is that true, MVVM stands for Model View Service Model?",
                    OptionA = "True", OptionB = "False", Answer = "B", Type = "True and False"},

                new Quiz { Week = 7, Number = 4, Question = "What difference does the 5th generation computer have from other generation computers?",
                    OptionA = "Technological Advancement", OptionB = "Scientific code", OptionC = "Object Oriented Programming", OptionD = "All of the Above", Answer = "A", Type = "Multiple Choice"},

                new Quiz { Week = 7, Number = 5, Question = "Which of the following is the 1's complement of 10?",
                    OptionA = "01", OptionB = "110", OptionC = "11", OptionD = "10", Answer = "A", Type = "Multiple Choice"},
                
                // Week8
                new Quiz { Week = 8, Number = 1, Question = "The brain of any computer system is",
                    OptionA = "ALU", OptionB = "Memory", OptionC = "CPU", OptionD = "Control Unit", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 8, Number = 2, Question = "Any type of storage that is used for holding information between steps in its processing is",
                    OptionA = "CPU", OptionB = "Primary Storage", OptionC = "Intermediate Storage", OptionD = "Internal Storage", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 8, Number = 3, Question = "A program component that allows structuring of a program in an unusual way is known as",
                    OptionA = "Quene", OptionB = "Correlation", OptionC = "Coroutine", OptionD = "Diagonalization", Answer = "C", Type = "Multiple Choice"},

                new Quiz { Week = 8, Number = 4, Question = "A single packet on a data link is known as",
                    OptionA = "Path", OptionB = "Frame", OptionC = "Block", OptionD = "Group", Answer = "Frame", Type = "Multiple Choice"},

                new Quiz { Week = 8, Number = 5, Question = "",
                    OptionA = "", OptionB = "", OptionC = "", OptionD = "", Answer = "", Type = "Multiple Choice"},


            };
        }
        public Task<bool> AddItemAsync(Quiz item)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteItemAsync(int week, int number)
        {
            throw new NotImplementedException();
        }

        public async Task<Quiz> GetItemAsync(int week, int number)
        {
            return await Task.FromResult(quizItems.FirstOrDefault(s => s.Week == week && s.Number == number));
        }

        public async Task<List<Quiz>> GetItemsAsync(int week, bool forceRefresh = false)
        {
            List<Quiz> choosedWeek = new List<Quiz>();
            foreach (Quiz quiz in quizItems)
            {
                if (quiz.Week == week)
                {
                    choosedWeek.Add(quiz);
                }
            }

            return choosedWeek;
        }
        public async Task<bool> UpdateItemAsync(int ind, string newone)
        {
            throw new NotImplementedException();
        }
    }
}
