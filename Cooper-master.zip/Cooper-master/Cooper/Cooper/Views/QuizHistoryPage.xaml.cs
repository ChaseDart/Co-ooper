﻿using System;
using System.Collections.Generic;
using Cooper.ViewModels;
using Xamarin.Forms;

namespace Cooper.Views
{
    public partial class QuizHistoryPage : ContentPage
    {
        public QuizHistoryPage()
        {
            InitializeComponent();
        }
    }
}
