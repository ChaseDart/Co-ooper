﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cooper.Models;
using Cooper.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Cooper.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Flashcard : ContentPage
    {
        public Flashcard()
        {
            InitializeComponent();
        }
    }
}