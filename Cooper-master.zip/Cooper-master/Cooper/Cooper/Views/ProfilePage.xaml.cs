﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ProgressRingControl.Forms.Plugin;
using Cooper.Models;
using Cooper.ViewModels;

using ChartEntry = Microcharts.ChartEntry;
using SkiaSharp;
using Microcharts;
using System.Windows.Input;
using Cooper.Services;
using Xamarin.Forms.Internals;

namespace Cooper.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProfilePage : ContentPage
    {
        public ProfilePage()
        {
            InitializeComponent();

            MicroChart1.HeightRequest = Application.Current.MainPage.Width;

            this.BindingContext = new ProfilePageViewModel();
            base.OnAppearing();
            ProfilePageViewModel profilePageViewModel = new ProfilePageViewModel();
            Class1Ring.ProgressTo(profilePageViewModel.ClassScoreD[0], 1500, Easing.CubicInOut);
            Class2Ring.ProgressTo(profilePageViewModel.ClassScoreD[1], 1500, Easing.CubicInOut);
            Class3Ring.ProgressTo(profilePageViewModel.ClassScoreD[2], 1500, Easing.CubicInOut);
            Class4Ring.ProgressTo(profilePageViewModel.ClassScoreD[3], 1500, Easing.CubicInOut);
        }
    }
}