﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cooper
{
    class ScoreValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            //100 percentage is maximum
            return (double)value / 100;

        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return new NotImplementedException();
        }
    }
}
