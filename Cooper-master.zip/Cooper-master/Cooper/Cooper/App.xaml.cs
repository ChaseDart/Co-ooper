﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Cooper.Services;
using Cooper.Views;
using Cooper.Models;

namespace Cooper
{
    public partial class App : Application
    {
        static AppDatabase database;
        public static AppDatabase Database
        {
            get
            {
                if(database == null)
                {
                    database = new AppDatabase();
                }
                return database;
            }
            set
            {

            }
        }
        public App()
        {
            InitializeComponent();
            DependencyService.Register<MockQuizDataStore>();
            DependencyService.Register<MockUnitDataStore>();
            DependencyService.Register<FlashCardsDataStore>();
            DependencyService.Register<QuizWeekStatusDatabase>();
            MainPage = new AppShell();

            Device.SetFlags(new[]
            {
                "RadioButton_Experimental"
            });
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
