﻿using System;
using System.Collections.Generic;
using Cooper.ViewModels;
using Cooper.Views;
using Xamarin.Forms;

namespace Cooper
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();/*
            Routing.RegisterRoute(nameof(ItemDetailPage), typeof(ItemDetailPage));
            Routing.RegisterRoute(nameof(NewItemPage), typeof(NewItemPage));*/
        }

    }
}
